Coloque aqui cópias dos PSDs que deseja testar, ou informe MANGACUT_PSD_TEST_DIR apontando para a pasta original.
Os arquivos PSD do usuário não são incluídos no pacote porque o conjunto original ocupa aproximadamente 1 GB.
