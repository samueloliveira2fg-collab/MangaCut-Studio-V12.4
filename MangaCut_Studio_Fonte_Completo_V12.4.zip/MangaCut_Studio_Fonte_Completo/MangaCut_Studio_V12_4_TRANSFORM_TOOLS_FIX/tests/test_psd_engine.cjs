'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi)].map(m => m[1]);
const engine = scripts.find(s => s.includes('global.MangaPSD={inspect,read,write}'));
assert.ok(engine, 'PSD engine must be present in index.html');
global.window = globalThis;
vm.runInThisContext(engine, { filename: 'MangaCut_PSD_Engine.js' });

async function readBuffer(buffer) {
  const file = { arrayBuffer: async () => buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength) };
  return window.MangaPSD.read(file);
}

function layer(name, parentId, shade) {
  const pixels = new Uint8ClampedArray(4 * 4 * 4);
  for (let i = 0; i < 16; i++) {
    const p = i * 4;
    pixels[p] = shade;
    pixels[p + 1] = (shade * 3) % 256;
    pixels[p + 2] = 255 - shade;
    pixels[p + 3] = 255;
  }
  return { name, parentId, pixels, opacity: 100, visible: true, locked: false, blend: 'source-over', x: 0, y: 0 };
}

(async () => {
  // Existing fixture: prove current bundled PSD still opens and retains pixel layers.
  const sample = fs.readFileSync(path.join(root, 'PSD_V10_roundtrip.psd'));
  const sampleParsed = await readBuffer(new Uint8Array(sample));
  assert.equal(sampleParsed.width, 735);
  assert.equal(sampleParsed.height, 630);
  assert.equal(sampleParsed.layers.length, 5);
  assert.equal(sampleParsed.flattened, false);

  // Regression fixture: 1,501 layers + nested folders. Older parser rejected >1,500,
  // and V12 flattened any PSD with more than 40 physical layers.
  const total = 1501;
  const layers = Array.from({ length: total }, (_, i) => layer(`Camada_${i + 1}`, 2, (i * 17) % 256));
  const groups = [
    { id: 1, name: 'Grupo principal', parentId: null, visible: true, locked: false, opacity: 100, collapsed: false, order: total - 1 },
    { id: 2, name: 'Subgrupo', parentId: 1, visible: true, locked: false, opacity: 85, collapsed: false, order: total - 1 },
  ];
  const composite = new Uint8ClampedArray(4 * 4 * 4);
  for (let i = 0; i < 16; i++) composite.set([12, 34, 56, 255], i * 4);
  const blob = await window.MangaPSD.write({
    width: 4,
    height: 4,
    layers,
    groups,
    renderLayer: l => l.pixels,
    composite,
  });
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const parsed = await readBuffer(bytes);
  assert.equal(parsed.layers.length, total, 'all 1,501 pixel layers must remain editable');
  assert.equal(parsed.flattened, false, 'large layer count must not trigger flattening');
  assert.equal(parsed.groups.length, 2, 'nested folder structure must be preserved');
  const main = parsed.groups.find(g => g.name === 'Grupo principal');
  const sub = parsed.groups.find(g => g.name === 'Subgrupo');
  assert.ok(main && sub, 'folder names must survive export/import');
  assert.equal(sub.parentId, main.id, 'nested parent relationship must survive');
  assert.ok(parsed.layers.every(l => l.parentId === sub.id), 'child layers must remain in the nested folder');
  assert.ok(parsed.warnings.some(w => w.includes('manter todas as camadas')), 'large document should warn about RAM without flattening');
  console.log('PASS PSD fixture 735x630: 5 pixel layers');
  console.log('PASS round-trip 1,501 pixel layers + 2 nested folders; no flattening');
})().catch(error => { console.error(error); process.exitCode = 1; });
