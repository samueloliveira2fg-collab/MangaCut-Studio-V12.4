# Teste com PSDs reais

Os PSDs do usuário não são copiados para este ZIP porque o conjunto ocupa aproximadamente 1 GB.

Para repetir a bateria com os arquivos originais, use Node.js 22 ou superior e execute:

```bash
MANGACUT_PSD_TEST_DIR="/caminho/para/seus/psds" node --expose-gc tests/test_real_psds.cjs
```

O teste importa cada PSD pelo mesmo motor `MangaPSD.read` usado pelo editor e verifica se todas as camadas e referências de pasta continuam presentes, sem achatamento automático.
