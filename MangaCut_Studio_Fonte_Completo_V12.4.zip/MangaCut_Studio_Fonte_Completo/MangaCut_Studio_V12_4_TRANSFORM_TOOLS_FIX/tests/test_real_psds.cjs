'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi)].map(m => m[1]);
const engine = scripts.find(s => s.includes('global.MangaPSD={inspect,read,write}'));
if (!engine) throw new Error('PSD engine not found in index.html');
const context = { window: {}, TextDecoder, TextEncoder, Uint8Array, Uint8ClampedArray, DataView, Blob, Response, DecompressionStream };
vm.createContext(context);
vm.runInContext(engine, context);

const inputDir = process.env.MANGACUT_PSD_TEST_DIR || path.join(__dirname, 'psd_inputs');
const files = fs.readdirSync(inputDir).filter(name => /\.psd$/i.test(name)).sort();
if (!files.length) throw new Error(`No PSD files found in ${inputDir}. Set MANGACUT_PSD_TEST_DIR to your PSD folder.`);

(async () => {
  const results = [];
  let passed = 0, failed = 0;
  for (const name of files) {
    let bytes = null, parsed = null;
    try {
      bytes = fs.readFileSync(path.join(inputDir, name));
      const view = new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      const file = { arrayBuffer: async () => view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength) };
      parsed = await context.window.MangaPSD.read(file);
      const ids = new Set(parsed.groups.map(group => group.id));
      const badGroupParents = parsed.groups.filter(group => group.parentId != null && !ids.has(group.parentId)).length;
      const badLayerParents = parsed.layers.filter(layer => layer.parentId != null && !ids.has(layer.parentId)).length;
      const ok = !parsed.flattened && parsed.layers.length === parsed.originalLayerCount && !badGroupParents && !badLayerParents;
      if (ok) passed++; else failed++;
      results.push({ name, status: ok ? 'PASS' : 'FAIL', width: parsed.width, height: parsed.height, layers: parsed.layers.length, groups: parsed.groups.length, flattened: parsed.flattened, badGroupParents, badLayerParents, warnings: parsed.warnings.length });
    } catch (error) {
      failed++;
      results.push({ name, status: 'ERROR', error: String(error.message || error) });
    }
    bytes = null; parsed = null;
    if (global.gc) global.gc();
  }
  const report = { summary: { total: files.length, passed, failed }, results };
  const output = process.env.MANGACUT_PSD_TEST_OUTPUT || path.join(__dirname, 'real_psd_import_results.json');
  fs.writeFileSync(output, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report.summary));
  if (failed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
