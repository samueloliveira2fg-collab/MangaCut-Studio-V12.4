'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi)].map(m=>m[1]);
const engine=scripts.find(s=>s.includes('global.MangaPSD={inspect,read,write}'));
const c={window:{},TextDecoder,TextEncoder,Uint8Array,Uint8ClampedArray,DataView,Blob,Response,DecompressionStream};vm.createContext(c);vm.runInContext(engine,c);
(async()=>{
 const pixels=new Uint8ClampedArray(4*4*4);for(let i=0;i<16;i++)pixels.set([i*10,i*10,i*10,255],i*4);
 const composite=pixels.slice();
 const blob=await c.window.MangaPSD.write({width:4,height:4,colorMode:1,layers:[{name:'Gray layer',pixels,parentId:null,opacity:100,visible:true,locked:false,blend:'source-over'}],groups:[],renderLayer:l=>l.pixels,composite});
 const bytes=new Uint8Array(await blob.arrayBuffer()),info=c.window.MangaPSD.inspect(bytes);
 assert.equal(info.mode,1);assert.equal(info.channels,2);
 const file={arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};
 const parsed=await c.window.MangaPSD.read(file);
 assert.equal(parsed.colorMode,1);assert.equal(parsed.layers.length,1);
 for(let i=0;i<16;i++){const p=i*4;assert.equal(parsed.layers[0].pixels[p],i*10);assert.equal(parsed.layers[0].pixels[p+1],i*10);assert.equal(parsed.layers[0].pixels[p+2],i*10);assert.equal(parsed.layers[0].pixels[p+3],255)}
 console.log('PASS grayscale native PSD: mode=1, channels=2, pixel values and alpha preserved');
})().catch(e=>{console.error(e);process.exitCode=1});
