const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync('index.html', 'utf8');
const match = html.match(/function screenToLayerPoint\(x,y,l=activeLayer\(\),clampBounds=true,T=null\)\{[\s\S]*?\n    \}/);
assert(match, 'screenToLayerPoint must exist in the editor source');

let layer = { x: 0, y: 0 };
const context = {
  width: 100,
  height: 80,
  activeLayer: () => layer,
  transformInfo: () => layer._transformInfo,
  Math,
};
vm.createContext(context);
vm.runInContext(match[0], context);

function check(label, input, expected, transformInfo = null) {
  layer = { x: input.layerX || 0, y: input.layerY || 0, _transformInfo: transformInfo };
  const actual = context.screenToLayerPoint(input.x, input.y, layer);
  assert.ok(Math.abs(actual.x - expected.x) < 1e-8, `${label}: x ${actual.x} != ${expected.x}`);
  assert.ok(Math.abs(actual.y - expected.y) < 1e-8, `${label}: y ${actual.y} != ${expected.y}`);
}

check('identity + translation', { x: 20, y: 30, layerX: 5, layerY: 10 }, { x: 15, y: 20 },
  { transformed: false });
check('scale 2x', { x: 70, y: 50 }, { x: 60, y: 45 },
  { transformed: true, cx: 50, cy: 40, c: 1, sin: 0, sx: 2, sy: 2 });
check('rotation 90 degrees', { x: 50, y: 30 }, { x: 40, y: 40 },
  { transformed: true, cx: 50, cy: 40, c: 0, sin: 1, sx: 1, sy: 1 });
check('horizontal flip', { x: 40, y: 40 }, { x: 60, y: 40 },
  { transformed: true, cx: 50, cy: 40, c: 1, sin: 0, sx: -1, sy: 1 });
check('clamps to document bounds', { x: -50, y: 900 }, { x: 0, y: 79 },
  { transformed: false });
const outside = context.screenToLayerPoint(-12, 93, layer, false, { transformed: false });
assert.equal(outside.x, -12, 'unclamped mapping must retain off-layer X');
assert.equal(outside.y, 93, 'unclamped mapping must retain off-layer Y');

assert.match(html, /function pt\(e,local=true\)[\s\S]*?if\(local\)\{const p=screenToLayerPoint\(x,y\);return \{x:Math.floor\(p.x\),y:Math.floor\(p.y\)\}\}/,
  'pointer mapping must use inverse transform and return integer pixel indices');
assert.match(html, /function inspectPixel\(e\)[\s\S]*?pt\(e,true\)/,
  'pixel inspector must sample transformed layer coordinates');
assert.match(html, /screenCorners[\s\S]*?map\(\(\[x,y\]\)=>screenToLayerPoint\(x,y\)\)/,
  'object selection must map its visible rectangle into layer coordinates');
assert.match(html, /if\(maskViewing&&activeLayer\(\)\)[\s\S]*?screenToLayerPoint\(dx,dy,l,false,T\)/,
  'mask preview must follow layer transforms');
assert.match(html, /function drawSelection\(\)[\s\S]*?screenToLayerPoint\(dx,dy,l,false,T\)/,
  'selection overlay must follow layer transforms');
assert.match(html, /function moveRing\(e\)[\s\S]*?scaleX[\s\S]*?scaleY[\s\S]*?rotate\(/,
  'brush cursor must reflect layer scale and angle');

console.log('PASS inverse pointer mapping: identity, translation, scale, rotation, flip, bounds');
console.log('PASS inspector and object selection use transformed layer coordinates');
