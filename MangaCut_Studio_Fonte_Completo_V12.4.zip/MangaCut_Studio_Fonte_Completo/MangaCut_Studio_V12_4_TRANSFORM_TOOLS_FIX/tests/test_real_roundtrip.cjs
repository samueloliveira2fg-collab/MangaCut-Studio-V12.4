'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi)].map(m => m[1]);
const engine = scripts.find(s => s.includes('global.MangaPSD={inspect,read,write}'));
if (!engine) throw new Error('PSD engine not found');
const context = { window: {}, TextDecoder, TextEncoder, Uint8Array, Uint8ClampedArray, DataView, Blob, Response, DecompressionStream };
vm.createContext(context); vm.runInContext(engine, context);
const inputDir = process.env.MANGACUT_PSD_TEST_DIR || path.join(__dirname, 'psd_inputs');
const selected = process.argv.slice(2).length ? process.argv.slice(2) : ['1.psd', '2.psd', '6.psd', 'Gojo Combat.psd', 'Doriutaaaa.psd'];
(async () => {
  const results = [];
  for (const name of selected) {
    let first = null, second = null;
    try {
      const bytes = fs.readFileSync(path.join(inputDir, name));
      const view = new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength);
      const file = { arrayBuffer: async () => view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength) };
      first = await context.window.MangaPSD.read(file);
      const composite = first.originalComposite || new Uint8ClampedArray(first.width * first.height * 4);
      const blob = await context.window.MangaPSD.write({ width: first.width, height: first.height, layers: first.layers, groups: first.groups, colorMode: first.colorMode, renderLayer: layer => layer.pixels, composite });
      const output = new Uint8Array(await blob.arrayBuffer());
      second = await context.window.MangaPSD.read({ arrayBuffer: async () => output.buffer.slice(output.byteOffset, output.byteOffset + output.byteLength) });
      const layersMatch = first.layers.length === second.layers.length && first.layers.every((layer, i) => {
        const other = second.layers[i];
        if (layer.name !== other.name || layer.parentId !== other.parentId) return false;
        for (let p = 0; p < layer.pixels.length; p += 4) {
          if (layer.pixels[p + 3] !== other.pixels[p + 3]) return false;
          if (layer.pixels[p + 3] || other.pixels[p + 3]) if (layer.pixels[p] !== other.pixels[p] || layer.pixels[p + 1] !== other.pixels[p + 1] || layer.pixels[p + 2] !== other.pixels[p + 2]) return false;
        }
        return true;
      });
      const tree = groups => groups.map(g => ({ name: g.name, parent: groups.find(p => p.id === g.parentId)?.name || null })).sort((a, b) => a.name.localeCompare(b.name));
      const groupsMatch = JSON.stringify(tree(first.groups)) === JSON.stringify(tree(second.groups));
      const modeMatches = first.colorMode === second.colorMode;
      const pass = layersMatch && groupsMatch && modeMatches && !second.flattened;
      results.push({ name, status: pass ? 'PASS' : 'FAIL', inputLayers: first.layers.length, outputLayers: second.layers.length, inputGroups: first.groups.length, outputGroups: second.groups.length, layersAndVisiblePixels: layersMatch, groupTree: groupsMatch, inputColorMode:first.colorMode, outputColorMode:second.colorMode, colorMode:modeMatches, flattened: second.flattened, outputBytes: output.length });
    } catch (error) { results.push({ name, status: 'ERROR', error: String(error.message || error) }); }
    first = null; second = null; if (global.gc) global.gc();
  }
  for (const result of results) console.log(JSON.stringify(result));
  if (results.some(result => result.status !== 'PASS')) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
