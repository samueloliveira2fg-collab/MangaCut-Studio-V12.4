# MangaCut Studio — Fonte completa V12.4

Este pacote contém a fonte e os módulos que estão presentes no release V12.4 fornecido.

## Conteúdo
- `MangaCut_Studio_V12_4_TRANSFORM_TOOLS_FIX/index.html`: aplicação principal do editor (HTML/CSS/JavaScript integrado no arquivo).
- `ai_backend/`: serviço local Python/FastAPI para Anime Segmentation via ONNX Runtime, requisitos, inicializador Windows e testes.
- `ai_training/`: scripts Python para preparar dataset supervisionado e executar fine-tuning, requisitos e atalhos Windows.
- `tests/`: testes do motor PSD, Grayscale, coordenadas de transformação, importação de PSDs reais e round-trip; inclui resultados históricos JSON.
- `exemplos/`: 39 painéis de referência incluídos no release.
- `AUDITORIA_TECNICA_*.md`, `PESQUISA_*.md`, `RELEASE_MANIFEST.json`: auditorias, pesquisa e manifesto da release.
- arquivos PNG/SVG/PSD de teste e capturas incluídos no release.

## Sobre builds
A V12.4 entregue é uma aplicação web local cujo entrypoint é `index.html`. O ZIP de origem não contém uma pasta independente `dist/`, `build/`, executável `.exe` ou instalador. Portanto, não inventei builds que não existem no release. O `index.html` é o artefato executável da aplicação web incluído nesta versão.

## Limites desta cópia
Este ZIP reproduz os arquivos efetivamente presentes no release V12.4. Os 54 PSDs do armazenamento do usuário não fazem parte do ZIP original do código; eles são um corpus de teste separado e precisam ser enviados em arquivos de acervo separados quando disponíveis. Os pesos do modelo ONNX são baixados sob demanda pelo backend; não há checkpoint treinado pelo MangaCut incluído.

## Versão
Última versão confirmada: MangaCut Studio V12.4 — Transform Tools Fix.
